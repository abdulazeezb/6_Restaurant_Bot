
ReadMe


NOTES:

1.	Laptop used is Lenovo ideapad 520 having Windows 10 - 64 bit and NVIDIA GeForce MX150 graphics card.

2.	While testing, sometimes you may get "Asyncio.Timeout” error. Searched about it and found following on GitHub:

	In C:\Users\amith\venv\Lib\site-packages\rasa\core\channels\console.py (location could be different on different machine being used for testing), check current value of this variable:

	DEFAULT_STREAM_READING_TIMEOUT_IN_SECONDS = 10

	Please increase it to some higher value. Otherwise, we need to look for action which is taking longer to execute and make changes so that action does not take that long.

	We were getting this error only when trying to send email to some email id which is not existing like mentioned in Conversational_stories.pdf provided in case study. This behaviour is inconsistent and it is already known to Rasa team as per their comments on GitHub.

3.	Rasa version on laptop used is - Rasa 1.5.3. We started working on project in December 2019 and at that time, latest version of Rasa was 1.5.3.

4.	Below is the list of dependencies including versions for Rasa installed on laptop used:

	rasa (1.5.3)
	async-generator~=1.10 (from rasa) (1.10)
	packaging~=19.0 (from rasa) (19.2)
	aiohttp~=3.5 (from rasa) (3.6.2)
	gevent~=1.4 (from rasa) (1.4.0)
	twilio~=6.0 (from rasa) (6.35.1)
	tensorflow~=1.15.0 (from rasa) (1.15.0)
	ruamel.yaml~=0.15.0 (from rasa) (0.15.100)
	gast==0.2.2 (from rasa) (0.2.2)
	tensor2tensor~=1.14.0 (from rasa) (1.14.1)
	pytz~=2019.1 (from rasa) (2019.3)
	coloredlogs~=10.0 (from rasa) (10.0)
	slackclient~=1.3 (from rasa) (1.3.2)
	scipy~=1.2 (from rasa) (1.4.1)
	python-telegram-bot~=11.0 (from rasa) (11.1.0)
	terminaltables~=3.1 (from rasa) (3.1.0)
	rocketchat-API~=0.6.0 (from rasa) (0.6.36)
	absl-py>=0.8.0 (from rasa) (0.9.0)
	mattermostwrapper~=2.0 (from rasa) (2.1)
	python-engineio>=3.9.3 (from rasa) (3.11.1)
	requests>=2.20 (from rasa) (2.22.0)
	sanic~=19.9 (from rasa) (19.9.0)
	boto3~=1.9 (from rasa) (1.10.45)
	colorhash~=1.0 (from rasa) (1.0.2)
	apscheduler~=3.0 (from rasa) (3.6.3)
	multidict==4.6.1 (from rasa) (4.6.1)
	SQLAlchemy~=1.3.0 (from rasa) (1.3.12)
	kafka-python~=1.4 (from rasa) (1.4.7)
	jsonschema~=3.0 (from rasa) (3.2.0)
	jsonpickle~=1.1 (from rasa) (1.2)
	python-dateutil~=2.8 (from rasa) (2.8.1)
	pika~=1.0.0 (from rasa) (1.0.1)
	sanic-jwt~=1.3 (from rasa) (1.3.2)
	questionary>=1.1.0 (from rasa) (1.4.0)
	matplotlib~=3.0 (from rasa) (3.1.2)
	colorclass~=2.2 (from rasa) (2.2.0)
	python-socketio>=4.3.1 (from rasa) (4.4.0)
	pydot~=1.4 (from rasa) (1.4.1)
	scikit-learn~=0.20.2 (from rasa) (0.20.4)
	networkx~=2.3.0 (from rasa) (2.3)
	pymongo[srv,tls]~=3.8 (from rasa) (3.10.0)
	redis~=3.3.5 (from rasa) (3.3.11)
	numpy~=1.16 (from rasa) (1.18.0)
	sklearn-crfsuite~=0.3.6 (from rasa) (0.3.6)
	PyJWT~=1.7 (from rasa) (1.7.1)
	tqdm~=4.0 (from rasa) (4.41.0)
	webexteamssdk~=1.1 (from rasa) (1.2)
	fbmessenger~=6.0 (from rasa) (6.0.0)
	pykwalify~=1.7.0 (from rasa) (1.7.0)
	sanic-cors==0.9.9.post1 (from rasa) (0.9.9.post1)
	setuptools>=41.0.0 (from rasa) (41.2.0)
	tensorflow-probability~=0.7.0 (from rasa) (0.7.0)
	attrs>=18 (from rasa) (19.3.0)
	rasa-sdk~=1.5.0 (from rasa) (1.5.2)
	six (from packaging~=19.0->rasa) (1.13.0)
	pyparsing>=2.0.2 (from packaging~=19.0->rasa) (2.4.6)
	yarl<2.0,>=1.0 (from aiohttp~=3.5->rasa) (1.4.2)
	chardet<4.0,>=2.0 (from aiohttp~=3.5->rasa) (3.0.4)
	async-timeout<4.0,>=3.0 (from aiohttp~=3.5->rasa) (3.0.1)
	greenlet>=0.4.14; platform_python_implementation == "CPython" (from gevent~=1.4->rasa) (0.4.15)
	cffi>=1.11.5; sys_platform == "win32" and platform_python_implementation == "CPython" (from gevent~=1.4->rasa) (1.13.2)
	wrapt>=1.11.1 (from tensorflow~=1.15.0->rasa) (1.11.2)
	wheel>=0.26 (from tensorflow~=1.15.0->rasa) (0.33.6)
	google-pasta>=0.1.6 (from tensorflow~=1.15.0->rasa) (0.1.8)
	termcolor>=1.1.0 (from tensorflow~=1.15.0->rasa) (1.1.0)
	grpcio>=1.8.6 (from tensorflow~=1.15.0->rasa) (1.26.0)
	astor>=0.6.0 (from tensorflow~=1.15.0->rasa) (0.8.1)
	protobuf>=3.6.1 (from tensorflow~=1.15.0->rasa) (3.11.2)
	tensorflow-estimator==1.15.1 (from tensorflow~=1.15.0->rasa) (1.15.1)
	keras-preprocessing>=1.0.5 (from tensorflow~=1.15.0->rasa) (1.1.0)
	tensorboard<1.16.0,>=1.15.0 (from tensorflow~=1.15.0->rasa) (1.15.0)
	keras-applications>=1.0.8 (from tensorflow~=1.15.0->rasa) (1.0.8)
	opt-einsum>=2.3.2 (from tensorflow~=1.15.0->rasa) (3.1.0)
	flask (from tensor2tensor~=1.14.0->rasa) (1.1.1)
	pypng (from tensor2tensor~=1.14.0->rasa) (0.0.20)
	google-api-python-client (from tensor2tensor~=1.14.0->rasa) (1.7.11)
	bz2file (from tensor2tensor~=1.14.0->rasa) (0.98)
	oauth2client (from tensor2tensor~=1.14.0->rasa) (4.1.3)
	h5py (from tensor2tensor~=1.14.0->rasa) (2.10.0)
	Pillow (from tensor2tensor~=1.14.0->rasa) (6.2.1)
	tensorflow-gan (from tensor2tensor~=1.14.0->rasa) (2.0.0)
	kfac (from tensor2tensor~=1.14.0->rasa) (0.2.0)
	gin-config (from tensor2tensor~=1.14.0->rasa) (0.3.0)
	dopamine-rl (from tensor2tensor~=1.14.0->rasa) (3.0.1)
	gym (from tensor2tensor~=1.14.0->rasa) (0.15.4)
	future (from tensor2tensor~=1.14.0->rasa) (0.18.2)
	opencv-python (from tensor2tensor~=1.14.0->rasa) (4.1.2.30)
	sympy (from tensor2tensor~=1.14.0->rasa) (1.5)
	tensorflow-datasets (from tensor2tensor~=1.14.0->rasa) (1.3.2)
	mesh-tensorflow (from tensor2tensor~=1.14.0->rasa) (0.1.7)
	gunicorn (from tensor2tensor~=1.14.0->rasa) (20.0.4)
	humanfriendly>=4.7 (from coloredlogs~=10.0->rasa) (4.18)
	colorama; sys_platform == "win32" (from coloredlogs~=10.0->rasa) (0.4.3)
	websocket-client<0.55.0,>=0.35 (from slackclient~=1.3->rasa) (0.54.0)
	certifi (from python-telegram-bot~=11.0->rasa) (2019.11.28)
	cryptography (from python-telegram-bot~=11.0->rasa) (2.8)
	urllib3!=1.25.0,!=1.25.1,<1.26,>=1.21.1 (from requests>=2.20->rasa) (1.25.7)
	idna<2.9,>=2.5 (from requests>=2.20->rasa) (2.8)
	requests-async==0.5.0 (from sanic~=19.9->rasa) (0.5.0)
	httptools>=0.0.10 (from sanic~=19.9->rasa) (0.0.13)
	websockets<9.0,>=7.0 (from sanic~=19.9->rasa) (8.1)
	aiofiles>=0.3.0 (from sanic~=19.9->rasa) (0.4.0)
	jmespath<1.0.0,>=0.7.1 (from boto3~=1.9->rasa) (0.9.4)
	botocore<1.14.0,>=1.13.45 (from boto3~=1.9->rasa) (1.13.45)
	s3transfer<0.3.0,>=0.2.0 (from boto3~=1.9->rasa) (0.2.1)
	tzlocal>=1.2 (from apscheduler~=3.0->rasa) (2.0.0)
	importlib-metadata; python_version < "3.8" (from jsonschema~=3.0->rasa) (1.3.0)
	pyrsistent>=0.14.0 (from jsonschema~=3.0->rasa) (0.15.6)
	prompt-toolkit~=2.0 (from questionary>=1.1.0->rasa) (2.0.10)
	kiwisolver>=1.0.1 (from matplotlib~=3.0->rasa) (1.1.0)
	cycler>=0.10 (from matplotlib~=3.0->rasa) (0.10.0)
	decorator>=4.3.0 (from networkx~=2.3.0->rasa) (4.4.1)
	dnspython<2.0.0,>=1.16.0; extra == "srv" (from pymongo[srv,tls]~=3.8->rasa) (1.16.0)
	tabulate (from sklearn-crfsuite~=0.3.6->rasa) (0.8.6)
	python-crfsuite>=0.8.3 (from sklearn-crfsuite~=0.3.6->rasa) (0.9.6)
	requests-toolbelt (from webexteamssdk~=1.1->rasa) (0.9.1)
	PyYAML>=3.11 (from pykwalify~=1.7.0->rasa) (5.2)
	docopt>=0.6.2 (from pykwalify~=1.7.0->rasa) (0.6.2)
	sanic-plugins-framework>=0.8.2 (from sanic-cors==0.9.9.post1->rasa) (0.8.2)
	cloudpickle>=0.6.1 (from tensorflow-probability~=0.7.0->rasa) (1.2.2)
	ConfigArgParse>=0.14 (from rasa-sdk~=1.5.0->rasa) (0.15.2)
	pycparser (from cffi>=1.11.5; sys_platform == "win32" and platform_python_implementation == "CPython"->gevent~=1.4->rasa) (2.19)
	werkzeug>=0.11.15 (from tensorboard<1.16.0,>=1.15.0->tensorflow~=1.15.0->rasa) (0.16.0)
	markdown>=2.6.8 (from tensorboard<1.16.0,>=1.15.0->tensorflow~=1.15.0->rasa) (3.1.1)
	Jinja2>=2.10.1 (from flask->tensor2tensor~=1.14.0->rasa) (2.10.3)
	itsdangerous>=0.24 (from flask->tensor2tensor~=1.14.0->rasa) (1.1.0)
	click>=5.1 (from flask->tensor2tensor~=1.14.0->rasa) (7.0)
	uritemplate<4dev,>=3.0.0 (from google-api-python-client->tensor2tensor~=1.14.0->rasa) (3.0.1)
	google-auth-httplib2>=0.0.3 (from google-api-python-client->tensor2tensor~=1.14.0->rasa) (0.0.3)
	google-auth>=1.4.1 (from google-api-python-client->tensor2tensor~=1.14.0->rasa) (1.10.0)
	httplib2<1dev,>=0.9.2 (from google-api-python-client->tensor2tensor~=1.14.0->rasa) (0.15.0)
	pyasn1-modules>=0.0.5 (from oauth2client->tensor2tensor~=1.14.0->rasa) (0.2.7)
	pyasn1>=0.1.7 (from oauth2client->tensor2tensor~=1.14.0->rasa) (0.4.8)
	rsa>=3.1.4 (from oauth2client->tensor2tensor~=1.14.0->rasa) (4.0)
	tensorflow-hub>=0.2 (from tensorflow-gan->tensor2tensor~=1.14.0->rasa) (0.7.0)
	pyglet<=1.3.2,>=1.2.0 (from gym->tensor2tensor~=1.14.0->rasa) (1.3.2)
	mpmath>=0.19 (from sympy->tensor2tensor~=1.14.0->rasa) (1.1.0)
	dill (from tensorflow-datasets->tensor2tensor~=1.14.0->rasa) (0.3.1.1)
	promise (from tensorflow-datasets->tensor2tensor~=1.14.0->rasa) (2.3)
	tensorflow-metadata (from tensorflow-datasets->tensor2tensor~=1.14.0->rasa) (0.15.2)
	pyreadline; sys_platform == "win32" (from humanfriendly>=4.7->coloredlogs~=10.0->rasa) (2.1)
	httpcore==0.3.* (from requests-async==0.5.0->sanic~=19.9->rasa) (0.3.0)
	docutils<0.16,>=0.10 (from botocore<1.14.0,>=1.13.45->boto3~=1.9->rasa) (0.15.2)
	zipp>=0.5 (from importlib-metadata; python_version < "3.8"->jsonschema~=3.0->rasa) (0.6.0)
	wcwidth (from prompt-toolkit~=2.0->questionary>=1.1.0->rasa) (0.1.7)
	MarkupSafe>=0.23 (from Jinja2>=2.10.1->flask->tensor2tensor~=1.14.0->rasa) (1.1.1)
	cachetools<5.0,>=2.0.0 (from google-auth>=1.4.1->google-api-python-client->tensor2tensor~=1.14.0->rasa) (4.0.0)
	googleapis-common-protos (from tensorflow-metadata->tensorflow-datasets->tensor2tensor~=1.14.0->rasa) (1.6.0)
	h11==0.8.* (from httpcore==0.3.*->requests-async==0.5.0->sanic~=19.9->rasa) (0.8.1)
	h2==3.* (from httpcore==0.3.*->requests-async==0.5.0->sanic~=19.9->rasa) (3.1.1)
	rfc3986==1.* (from httpcore==0.3.*->requests-async==0.5.0->sanic~=19.9->rasa) (1.3.2)
	more-itertools (from zipp>=0.5->importlib-metadata; python_version < "3.8"->jsonschema~=3.0->rasa) (8.0.2)
	hpack<4,>=2.3 (from h2==3.*->httpcore==0.3.*->requests-async==0.5.0->sanic~=19.9->rasa) (3.0.0)
	hyperframe<6,>=5.2.0 (from h2==3.*->httpcore==0.3.*->requests-async==0.5.0->sanic~=19.9->rasa) (5.2.0)

5.	Below is the list of dependencies including versions for Rasa[spacy] installed on laptop used. Specific components are highlighted below:

	rasa[spacy] (1.5.3)
	absl-py>=0.8.0 (from rasa[spacy]) (0.9.0)
	setuptools>=41.0.0 (from rasa[spacy]) (41.2.0)
	terminaltables~=3.1 (from rasa[spacy]) (3.1.0)
	aiohttp~=3.5 (from rasa[spacy]) (3.6.2)
	requests>=2.20 (from rasa[spacy]) (2.22.0)
	attrs>=18 (from rasa[spacy]) (19.3.0)
	redis~=3.3.5 (from rasa[spacy]) (3.3.11)
	tensorflow-probability~=0.7.0 (from rasa[spacy]) (0.7.0)
	scipy~=1.2 (from rasa[spacy]) (1.4.1)
	rasa-sdk~=1.5.0 (from rasa[spacy]) (1.5.2)
	pika~=1.0.0 (from rasa[spacy]) (1.0.1)
	networkx~=2.3.0 (from rasa[spacy]) (2.3)
	colorhash~=1.0 (from rasa[spacy]) (1.0.2)
	pymongo[srv,tls]~=3.8 (from rasa[spacy]) (3.10.0)
	sklearn-crfsuite~=0.3.6 (from rasa[spacy]) (0.3.6)
	pykwalify~=1.7.0 (from rasa[spacy]) (1.7.0)
	PyJWT~=1.7 (from rasa[spacy]) (1.7.1)
	tqdm~=4.0 (from rasa[spacy]) (4.41.0)
	pydot~=1.4 (from rasa[spacy]) (1.4.1)
	fbmessenger~=6.0 (from rasa[spacy]) (6.0.0)
	matplotlib~=3.0 (from rasa[spacy]) (3.1.2)
	sanic~=19.9 (from rasa[spacy]) (19.9.0)
	numpy~=1.16 (from rasa[spacy]) (1.18.0)
	scikit-learn~=0.20.2 (from rasa[spacy]) (0.20.4)
	gevent~=1.4 (from rasa[spacy]) (1.4.0)
	sanic-cors==0.9.9.post1 (from rasa[spacy]) (0.9.9.post1)
	colorclass~=2.2 (from rasa[spacy]) (2.2.0)
	python-dateutil~=2.8 (from rasa[spacy]) (2.8.1)
	gast==0.2.2 (from rasa[spacy]) (0.2.2)
	jsonpickle~=1.1 (from rasa[spacy]) (1.2)
	python-socketio>=4.3.1 (from rasa[spacy]) (4.4.0)
	kafka-python~=1.4 (from rasa[spacy]) (1.4.7)
	slackclient~=1.3 (from rasa[spacy]) (1.3.2)
	coloredlogs~=10.0 (from rasa[spacy]) (10.0)
	webexteamssdk~=1.1 (from rasa[spacy]) (1.2)
	apscheduler~=3.0 (from rasa[spacy]) (3.6.3)
	python-telegram-bot~=11.0 (from rasa[spacy]) (11.1.0)
	multidict==4.6.1 (from rasa[spacy]) (4.6.1)
	sanic-jwt~=1.3 (from rasa[spacy]) (1.3.2)
	SQLAlchemy~=1.3.0 (from rasa[spacy]) (1.3.12)
	tensor2tensor~=1.14.0 (from rasa[spacy]) (1.14.1)
	questionary>=1.1.0 (from rasa[spacy]) (1.4.0)
	twilio~=6.0 (from rasa[spacy]) (6.35.1)
	python-engineio>=3.9.3 (from rasa[spacy]) (3.11.1)
	mattermostwrapper~=2.0 (from rasa[spacy]) (2.1)
	pytz~=2019.1 (from rasa[spacy]) (2019.3)
	async-generator~=1.10 (from rasa[spacy]) (1.10)
	boto3~=1.9 (from rasa[spacy]) (1.10.45)
	jsonschema~=3.0 (from rasa[spacy]) (3.2.0)
	packaging~=19.0 (from rasa[spacy]) (19.2)
	tensorflow~=1.15.0 (from rasa[spacy]) (1.15.0)
	rocketchat-API~=0.6.0 (from rasa[spacy]) (0.6.36)
	ruamel.yaml~=0.15.0 (from rasa[spacy]) (0.15.100)
	spacy<2.2,>=2.1; extra == "spacy" (from rasa[spacy]) (2.1.9)
	six (from absl-py>=0.8.0->rasa[spacy]) (1.13.0)
	yarl<2.0,>=1.0 (from aiohttp~=3.5->rasa[spacy]) (1.4.2)
	async-timeout<4.0,>=3.0 (from aiohttp~=3.5->rasa[spacy]) (3.0.1)
	chardet<4.0,>=2.0 (from aiohttp~=3.5->rasa[spacy]) (3.0.4)
	urllib3!=1.25.0,!=1.25.1,<1.26,>=1.21.1 (from requests>=2.20->rasa[spacy]) (1.25.7)
	idna<2.9,>=2.5 (from requests>=2.20->rasa[spacy]) (2.8)
	certifi>=2017.4.17 (from requests>=2.20->rasa[spacy]) (2019.11.28)
	cloudpickle>=0.6.1 (from tensorflow-probability~=0.7.0->rasa[spacy]) (1.2.2)
	decorator (from tensorflow-probability~=0.7.0->rasa[spacy]) (4.4.1)
	ConfigArgParse>=0.14 (from rasa-sdk~=1.5.0->rasa[spacy]) (0.15.2)
	dnspython<2.0.0,>=1.16.0; extra == "srv" (from pymongo[srv,tls]~=3.8->rasa[spacy]) (1.16.0)
	tabulate (from sklearn-crfsuite~=0.3.6->rasa[spacy]) (0.8.6)
	python-crfsuite>=0.8.3 (from sklearn-crfsuite~=0.3.6->rasa[spacy]) (0.9.6)
	docopt>=0.6.2 (from pykwalify~=1.7.0->rasa[spacy]) (0.6.2)
	PyYAML>=3.11 (from pykwalify~=1.7.0->rasa[spacy]) (5.2)
	pyparsing>=2.1.4 (from pydot~=1.4->rasa[spacy]) (2.4.6)
	kiwisolver>=1.0.1 (from matplotlib~=3.0->rasa[spacy]) (1.1.0)
	cycler>=0.10 (from matplotlib~=3.0->rasa[spacy]) (0.10.0)
	httptools>=0.0.10 (from sanic~=19.9->rasa[spacy]) (0.0.13)
	aiofiles>=0.3.0 (from sanic~=19.9->rasa[spacy]) (0.4.0)
	websockets<9.0,>=7.0 (from sanic~=19.9->rasa[spacy]) (8.1)
	requests-async==0.5.0 (from sanic~=19.9->rasa[spacy]) (0.5.0)
	cffi>=1.11.5; sys_platform == "win32" and platform_python_implementation == "CPython" (from gevent~=1.4->rasa[spacy]) (1.13.2)
	greenlet>=0.4.14; platform_python_implementation == "CPython" (from gevent~=1.4->rasa[spacy]) (0.4.15)
	sanic-plugins-framework>=0.8.2 (from sanic-cors==0.9.9.post1->rasa[spacy]) (0.8.2)
	websocket-client<0.55.0,>=0.35 (from slackclient~=1.3->rasa[spacy]) (0.54.0)
	colorama; sys_platform == "win32" (from coloredlogs~=10.0->rasa[spacy]) (0.4.3)
	humanfriendly>=4.7 (from coloredlogs~=10.0->rasa[spacy]) (4.18)
	requests-toolbelt (from webexteamssdk~=1.1->rasa[spacy]) (0.9.1)
	future (from webexteamssdk~=1.1->rasa[spacy]) (0.18.2)
	tzlocal>=1.2 (from apscheduler~=3.0->rasa[spacy]) (2.0.0)
	cryptography (from python-telegram-bot~=11.0->rasa[spacy]) (2.8)
	google-api-python-client (from tensor2tensor~=1.14.0->rasa[spacy]) (1.7.11)
	dopamine-rl (from tensor2tensor~=1.14.0->rasa[spacy]) (3.0.1)
	Pillow (from tensor2tensor~=1.14.0->rasa[spacy]) (6.2.1)
	gin-config (from tensor2tensor~=1.14.0->rasa[spacy]) (0.3.0)
	oauth2client (from tensor2tensor~=1.14.0->rasa[spacy]) (4.1.3)
	bz2file (from tensor2tensor~=1.14.0->rasa[spacy]) (0.98)
	tensorflow-gan (from tensor2tensor~=1.14.0->rasa[spacy]) (2.0.0)
	opencv-python (from tensor2tensor~=1.14.0->rasa[spacy]) (4.1.2.30)
	pypng (from tensor2tensor~=1.14.0->rasa[spacy]) (0.0.20)
	mesh-tensorflow (from tensor2tensor~=1.14.0->rasa[spacy]) (0.1.7)
	tensorflow-datasets (from tensor2tensor~=1.14.0->rasa[spacy]) (1.3.2)
	h5py (from tensor2tensor~=1.14.0->rasa[spacy]) (2.10.0)
	gym (from tensor2tensor~=1.14.0->rasa[spacy]) (0.15.4)
	kfac (from tensor2tensor~=1.14.0->rasa[spacy]) (0.2.0)
	gunicorn (from tensor2tensor~=1.14.0->rasa[spacy]) (20.0.4)
	sympy (from tensor2tensor~=1.14.0->rasa[spacy]) (1.5)
	flask (from tensor2tensor~=1.14.0->rasa[spacy]) (1.1.1)
	prompt-toolkit~=2.0 (from questionary>=1.1.0->rasa[spacy]) (2.0.10)
	botocore<1.14.0,>=1.13.45 (from boto3~=1.9->rasa[spacy]) (1.13.45)
	jmespath<1.0.0,>=0.7.1 (from boto3~=1.9->rasa[spacy]) (0.9.4)
	s3transfer<0.3.0,>=0.2.0 (from boto3~=1.9->rasa[spacy]) (0.2.1)
	pyrsistent>=0.14.0 (from jsonschema~=3.0->rasa[spacy]) (0.15.6)
	importlib-metadata; python_version < "3.8" (from jsonschema~=3.0->rasa[spacy]) (1.3.0)
	grpcio>=1.8.6 (from tensorflow~=1.15.0->rasa[spacy]) (1.26.0)
	tensorflow-estimator==1.15.1 (from tensorflow~=1.15.0->rasa[spacy]) (1.15.1)
	keras-preprocessing>=1.0.5 (from tensorflow~=1.15.0->rasa[spacy]) (1.1.0)
	astor>=0.6.0 (from tensorflow~=1.15.0->rasa[spacy]) (0.8.1)
	wheel>=0.26 (from tensorflow~=1.15.0->rasa[spacy]) (0.33.6)
	protobuf>=3.6.1 (from tensorflow~=1.15.0->rasa[spacy]) (3.11.2)
	keras-applications>=1.0.8 (from tensorflow~=1.15.0->rasa[spacy]) (1.0.8)
	tensorboard<1.16.0,>=1.15.0 (from tensorflow~=1.15.0->rasa[spacy]) (1.15.0)
	google-pasta>=0.1.6 (from tensorflow~=1.15.0->rasa[spacy]) (0.1.8)
	termcolor>=1.1.0 (from tensorflow~=1.15.0->rasa[spacy]) (1.1.0)
	wrapt>=1.11.1 (from tensorflow~=1.15.0->rasa[spacy]) (1.11.2)
	opt-einsum>=2.3.2 (from tensorflow~=1.15.0->rasa[spacy]) (3.1.0)
	murmurhash<1.1.0,>=0.28.0 (from spacy<2.2,>=2.1; extra == "spacy"->rasa[spacy]) (1.0.2)
	cymem<2.1.0,>=2.0.2 (from spacy<2.2,>=2.1; extra == "spacy"->rasa[spacy]) (2.0.3)
	srsly<1.1.0,>=0.0.6 (from spacy<2.2,>=2.1; extra == "spacy"->rasa[spacy]) (0.2.0)
	blis<0.3.0,>=0.2.2 (from spacy<2.2,>=2.1; extra == "spacy"->rasa[spacy]) (0.2.4)
	preshed<2.1.0,>=2.0.1 (from spacy<2.2,>=2.1; extra == "spacy"->rasa[spacy]) (2.0.1)
	wasabi<1.1.0,>=0.2.0 (from spacy<2.2,>=2.1; extra == "spacy"->rasa[spacy]) (0.4.2)
	plac<1.0.0,>=0.9.6 (from spacy<2.2,>=2.1; extra == "spacy"->rasa[spacy]) (0.9.6)
	thinc<7.1.0,>=7.0.8 (from spacy<2.2,>=2.1; extra == "spacy"->rasa[spacy]) (7.0.8)
	httpcore==0.3.* (from requests-async==0.5.0->sanic~=19.9->rasa[spacy]) (0.3.0)
	pycparser (from cffi>=1.11.5; sys_platform == "win32" and platform_python_implementation == "CPython"->gevent~=1.4->rasa[spacy]) (2.19)
	pyreadline; sys_platform == "win32" (from humanfriendly>=4.7->coloredlogs~=10.0->rasa[spacy]) (2.1)
	uritemplate<4dev,>=3.0.0 (from google-api-python-client->tensor2tensor~=1.14.0->rasa[spacy]) (3.0.1)
	google-auth>=1.4.1 (from google-api-python-client->tensor2tensor~=1.14.0->rasa[spacy]) (1.10.0)
	google-auth-httplib2>=0.0.3 (from google-api-python-client->tensor2tensor~=1.14.0->rasa[spacy]) (0.0.3)
	httplib2<1dev,>=0.9.2 (from google-api-python-client->tensor2tensor~=1.14.0->rasa[spacy]) (0.15.0)
	pyasn1-modules>=0.0.5 (from oauth2client->tensor2tensor~=1.14.0->rasa[spacy]) (0.2.7)
	pyasn1>=0.1.7 (from oauth2client->tensor2tensor~=1.14.0->rasa[spacy]) (0.4.8)
	rsa>=3.1.4 (from oauth2client->tensor2tensor~=1.14.0->rasa[spacy]) (4.0)
	tensorflow-hub>=0.2 (from tensorflow-gan->tensor2tensor~=1.14.0->rasa[spacy]) (0.7.0)
	dill (from tensorflow-datasets->tensor2tensor~=1.14.0->rasa[spacy]) (0.3.1.1)
	tensorflow-metadata (from tensorflow-datasets->tensor2tensor~=1.14.0->rasa[spacy]) (0.15.2)
	promise (from tensorflow-datasets->tensor2tensor~=1.14.0->rasa[spacy]) (2.3)
	pyglet<=1.3.2,>=1.2.0 (from gym->tensor2tensor~=1.14.0->rasa[spacy]) (1.3.2)
	mpmath>=0.19 (from sympy->tensor2tensor~=1.14.0->rasa[spacy]) (1.1.0)
	Jinja2>=2.10.1 (from flask->tensor2tensor~=1.14.0->rasa[spacy]) (2.10.3)
	Werkzeug>=0.15 (from flask->tensor2tensor~=1.14.0->rasa[spacy]) (0.16.0)
	click>=5.1 (from flask->tensor2tensor~=1.14.0->rasa[spacy]) (7.0)
	itsdangerous>=0.24 (from flask->tensor2tensor~=1.14.0->rasa[spacy]) (1.1.0)
	wcwidth (from prompt-toolkit~=2.0->questionary>=1.1.0->rasa[spacy]) (0.1.7)
	docutils<0.16,>=0.10 (from botocore<1.14.0,>=1.13.45->boto3~=1.9->rasa[spacy]) (0.15.2)
	zipp>=0.5 (from importlib-metadata; python_version < "3.8"->jsonschema~=3.0->rasa[spacy]) (0.6.0)
	markdown>=2.6.8 (from tensorboard<1.16.0,>=1.15.0->tensorflow~=1.15.0->rasa[spacy]) (3.1.1)
	h11==0.8.* (from httpcore==0.3.*->requests-async==0.5.0->sanic~=19.9->rasa[spacy]) (0.8.1)
	h2==3.* (from httpcore==0.3.*->requests-async==0.5.0->sanic~=19.9->rasa[spacy]) (3.1.1)
	rfc3986==1.* (from httpcore==0.3.*->requests-async==0.5.0->sanic~=19.9->rasa[spacy]) (1.3.2)
	cachetools<5.0,>=2.0.0 (from google-auth>=1.4.1->google-api-python-client->tensor2tensor~=1.14.0->rasa[spacy]) (4.0.0)
	googleapis-common-protos (from tensorflow-metadata->tensorflow-datasets->tensor2tensor~=1.14.0->rasa[spacy]) (1.6.0)
	MarkupSafe>=0.23 (from Jinja2>=2.10.1->flask->tensor2tensor~=1.14.0->rasa[spacy]) (1.1.1)
	more-itertools (from zipp>=0.5->importlib-metadata; python_version < "3.8"->jsonschema~=3.0->rasa[spacy]) (8.0.2)
	hpack<4,>=2.3 (from h2==3.*->httpcore==0.3.*->requests-async==0.5.0->sanic~=19.9->rasa[spacy]) (3.0.0)
	hyperframe<6,>=5.2.0 (from h2==3.*->httpcore==0.3.*->requests-async==0.5.0->sanic~=19.9->rasa[spacy]) (5.2.0)

6.	If you have installed latest version of Rasa which is Rasa 1.6.1 and on it, if you try to run our model then you may get error something like this:

	rasa.nlu.model.UnsupportedModelError: The model version is too old to be loaded by this Rasa NLU instance. Either retrain the model, or run with an older version. Model version: 1.5.3 Instance version: 1.6.1
	
	You may have lower version of Rasa as well and may get something similar so in that case also, please follow below link and uninstall your current version of Rasa and install Rasa 1.5.3.
	
	https://forum.rasa.com/t/getting-rasa-nlu-model-unsupportedmodelerror/10185  

	pip uninstall rasa

	pip install rasa==<version of rasa, e.g. 0.15.0a6>

7.	Just in case, you decide to keep your current version of Rasa (1.6.1) and remove our current model and retrain again then you may get some warning like below while running rasa shell. We just found it on Github being faced by others and did not try to solve it as we did not want to unnecessarily upgrade our versions and run into issues. You may please ignore these warnings as bot should work fine otherwise. And our bot works perfectly fine on Rasa 1.5.3 anyway.


	UserWarning: Number of features (1) for attribute 'text_dense_features' does not match number of tokens (12). Set 'return_sequence' to true in the corresponding featurizer in order to make use of the features in 'CRFEntityExtractor'.
  	f"Number of features ({len(features)}) for attribute "


8.	Command used to train the bot:

	rasa train


Deployment on Slack and YouTube video link:

1.	We have deployed bot on Slack. Below are details:

	Slack URL		- restro-bot-amitgoel.slack.com
	Slack workspace		- restaurant-bot-mlai9-amitg
	Slack app		- restaurant_bot_ag
	Slack channel		- #my_restaurant_bot_ag

2.	Below is the link to YouTube video showing Restaurant bot on Slack.

	https://youtu.be/FYnuKZmAaBw


Following installations were done:

1.	Download Visual Studio 2019 Community version from https://visualstudio.microsoft.com/downloads/. Start installer and choose - (Desktop Development with C++) and install.

2.	Download python 3.7.6 for windows 64 bit from https://www.python.org/downloads/release/python-376/ and install it. Upgrade pip. And then create a new virtual environment as per instructions provided in the module.


3.	Activate virtual environment and install Rasa and Rasa X as per instructions provided in the module. Rasa version is Rasa 1.5.3.

4.	In same active virtual environment, install Rasa NLU and Spacy as per instructions provided in the module.

5.	Was getting lot of errors on missing dlls. Searched about and carried out following steps based on kind of issues faced:

	a.	Installed CUDA 10 and related cuDNN libraries using this link https://towardsdatascience.com/installing-tensorflow-with-cuda-cudnn-and-gpu-support-on-windows-10-60693e46e781

	b.	After that started GeForce experience from start programs on my laptop and installed game ready driver.

	c.	Post that tried to run nvidia-smi and found it working.

	d.	Post that didn't face any problem.


Points need to be followed in order to run restaurant bot:

1.	Generated new Zomato API key but while submitting, have removed it. Please update user key in bot folder in actions.py file in this line (line no 18) – 

	user_key = "xxxxxx"

	Replace xxxxxx with actual key.

2.	In data/static/smtp_details.txt file, please update details in these lines (line no 3, 4, and 5) – 

	username=xxxxxx@xxxx.xxx
	password=xxxxxx
	from_email=xxxxxx@xxxx.xxx

	Please do not use any enclosing quotes. Please ensure gmail id used, has secure access feature enabled.

3.	Please note that zomatopy.py is different from the one provided in rasa_basic_folder in the module. We have added one more function in it based on need so please ensure that all files in bot folder are used as is.

4.	Run below command before you want to start rasa x (Rasa X) just in case:

	set GIT_PYTHON_REFRESH=quiet

5.	Run bot in command prompt:

	a). Start command prompt as administrator. Then activate virtual environment, go to bot folder having all files and then start rasa action server using command "rasa run actions".

	b). Start another command prompt as administrator and then activate virtual environment, go to bot folder having all files and then start rasa shell using command "rasa shell" (for testing bot on command line) or rasa in interactive mode using command "rasa interactive" (to create stories).

6.	Run bot on Slack:

	a). Start command prompt as administrator. Then activate virtual environment, go to bot folder having all files and then start rasa action server using command "rasa run actions".

	b). Start another command prompt as administrator, activate virtual environment, go to bot folder having all files and then start rasa server using command "rasa run".

	c). Start another command prompt as administrator, go to folder having ngrok and start ngrok using command "ngrok http 5005". 5005 is the port on which rasa server was started in above step.

	d). Then copy url provided by ngrok and update in restaurant bot app deployed in Slack in app management under event subscriptions like this: 

	https://xxxxxx.ngrok.io/webhooks/slack/webhook

















====================================== END OF DOCUMENT ======================================

